# Plugin de Botón de Descarga para Elementor

Este plugin añade un widget personalizado a Elementor que te permite crear botones de descarga de archivos con múltiples opciones de personalización.

## Características

- ✅ Selector de archivos desde la biblioteca de medios de WordPress
- ✅ Texto personalizable del botón
- ✅ Icono configurable con posición ajustable (izquierda/derecha)
- ✅ Opción para forzar descarga o abrir en nueva pestaña
- ✅ Estilos completamente personalizables (colores, tipografía, padding, bordes, sombras)
- ✅ Estados normal y hover con animaciones
- ✅ Responsive: ajustes diferentes para móvil, tablet y escritorio
- ✅ Compatible con cualquier tipo de archivo (PDF, imágenes, videos, documentos, etc.)

## Requisitos

- WordPress 5.0 o superior
- Elementor 3.0.0 o superior
- PHP 7.4 o superior

## Instalación

### Opción 1: Instalación Manual

1. Descarga todos los archivos del plugin
2. Crea una carpeta llamada `elementor-download-button` en el directorio de plugins de WordPress
3. Copia los siguientes archivos dentro de esa carpeta:
   ```
   wp-content/plugins/elementor-download-button/
   ├── elementor-download-button.php
   └── widgets/
       └── download-button-widget.php
   ```
4. Ve a **Plugins** en tu panel de WordPress
5. Busca "Elementor Download Button" y actívalo

### Opción 2: Subir como ZIP

1. Comprime todos los archivos en un ZIP asegurándote de que la estructura sea:
   ```
   elementor-download-button.zip
   └── elementor-download-button/
       ├── elementor-download-button.php
       └── widgets/
           └── download-button-widget.php
   ```
2. Ve a **Plugins > Añadir nuevo > Subir plugin**
3. Selecciona el archivo ZIP y sube
4. Activa el plugin

## Uso

### Añadir el Widget

1. Edita una página con Elementor
2. Busca el widget **"Botón de Descarga"** en la categoría "Descarga"
3. Arrastra el widget al área deseada

### Configurar el Botón

#### Pestaña Contenido

**Archivo para Descargar:**
- Haz clic en "Elegir archivo"
- Selecciona un archivo de tu biblioteca de medios o sube uno nuevo
- Soporta todos los tipos de archivo

**Texto del Botón:**
- Escribe el texto que aparecerá en el botón
- Por defecto: "Descargar Archivo"

**Icono:**
- Activa/desactiva el icono
- Elige el icono de la biblioteca de iconos de Elementor
- Selecciona la posición (izquierda o derecha del texto)

**Forzar Descarga:**
- **Activado:** El archivo se descarga directamente
- **Desactivado:** El archivo se abre en una nueva pestaña (útil para PDFs que quieres que se vean primero)

**Alineación:**
- Alinea el botón a la izquierda, centro, derecha o justificado
- Configuración responsive: puedes tener diferentes alineaciones en móvil, tablet y escritorio

#### Pestaña Estilo - Botón

**Tipografía:**
- Familia de fuente, tamaño, peso, transformación, estilo, decoración, espaciado de letras

**Padding:**
- Espaciado interno del botón
- Por defecto: 15px arriba/abajo, 30px izquierda/derecha

**Radio del Borde:**
- Define esquinas redondeadas

**Estado Normal:**
- Color del texto
- Color de fondo (sólido o degradado)
- Bordes
- Sombras

**Estado Hover:**
- Color del texto al pasar el mouse
- Color de fondo al pasar el mouse
- Bordes al pasar el mouse
- Sombras al pasar el mouse
- Animación hover (múltiples efectos disponibles)

#### Pestaña Estilo - Icono

**Color del Icono:**
- Elige el color del icono

**Tamaño del Icono:**
- Ajusta el tamaño entre 10px y 100px

**Espaciado:**
- Separación entre el icono y el texto

## Ejemplos de Uso

### Ejemplo 1: Botón de Descarga de PDF
- Archivo: Catálogo.pdf
- Texto: "Descargar Catálogo"
- Icono: fa-file-pdf (izquierda)
- Forzar descarga: Sí
- Estilo: Fondo azul, texto blanco, esquinas redondeadas

### Ejemplo 2: Ver Imagen
- Archivo: Infografía.jpg
- Texto: "Ver Infografía"
- Icono: fa-eye (derecha)
- Forzar descarga: No (se abrirá en nueva pestaña)
- Estilo: Fondo degradado, efecto hover con elevación

### Ejemplo 3: Descarga de Documento
- Archivo: Manual-Usuario.docx
- Texto: "Descargar Manual"
- Icono: fa-download
- Forzar descarga: Sí
- Estilo: Botón con borde, fondo transparente, hover con relleno

## Personalización Avanzada

### CSS Personalizado

Puedes añadir CSS personalizado en **Elementor > Configuración personalizada > CSS** o en tu tema:

```css
/* Cambiar el cursor al pasar sobre el botón */
.download-button {
    cursor: pointer;
    transition: all 0.3s ease;
}

/* Animación personalizada */
.download-button:hover {
    transform: translateY(-3px);
}

/* Estilo para dispositivos móviles */
@media (max-width: 768px) {
    .download-button {
        width: 100%;
        display: block;
        text-align: center;
    }
}
```

## Solución de Problemas

### El widget no aparece en Elementor
- Verifica que Elementor esté instalado y activado
- Verifica que estés usando Elementor 3.0.0 o superior
- Desactiva y reactiva el plugin

### El archivo no se descarga
- Verifica que la URL del archivo sea correcta
- Verifica los permisos del archivo en el servidor
- Prueba desactivando "Forzar descarga" para ver si se abre en el navegador

### Los estilos no se aplican
- Limpia la caché de Elementor: **Elementor > Herramientas > Regenerar CSS**
- Limpia la caché del navegador
- Limpia la caché del plugin de caché si usas uno

## Changelog

### Versión 1.0.0
- Lanzamiento inicial
- Widget de botón de descarga básico
- Estilos personalizables
- Soporte para iconos
- Responsive

## Soporte

Si encuentras algún problema o tienes sugerencias, puedes:
- Crear un issue en el repositorio
- Contactar al desarrollador

## Créditos

Desarrollado para facilitar la creación de botones de descarga en sitios web creados con Elementor.

## Licencia

GPL v2 o posterior
