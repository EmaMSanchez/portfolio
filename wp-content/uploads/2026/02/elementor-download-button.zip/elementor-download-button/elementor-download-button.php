<?php
/**
 * Plugin Name: Elementor Download Button
 * Description: Añade un widget de botón de descarga personalizable para Elementor
 * Version: 1.0.1
 * Author: Emanuel Sanchez
 * Text Domain: elementor-download-button
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('ELEMENTOR_DOWNLOAD_BUTTON_VERSION', '1.0.1');
define('ELEMENTOR_DOWNLOAD_BUTTON_PATH', plugin_dir_path(__FILE__));
define('ELEMENTOR_DOWNLOAD_BUTTON_URL', plugin_dir_url(__FILE__));

/**
 * Main Plugin Class
 */
final class Elementor_Download_Button {
    
    private static $_instance = null;
    
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct() {
        add_action('plugins_loaded', [$this, 'init']);
    }
    
    public function init() {
        // Check if Elementor is installed and activated
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', [$this, 'admin_notice_missing_elementor']);
            return;
        }
        
        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, '3.0.0', '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }
        
        // Register Widget
        add_action('elementor/widgets/register', [$this, 'register_widgets']);
        
        // Register Widget Category
        add_action('elementor/elements/categories_registered', [$this, 'add_elementor_widget_categories']);
        
        // Enqueue Styles for Frontend
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueue_styles']);
        
        // Enqueue Styles for Editor
        add_action('elementor/editor/after_enqueue_styles', [$this, 'enqueue_styles']);
    }
    
    public function enqueue_styles() {
        wp_enqueue_style(
            'elementor-download-button',
            ELEMENTOR_DOWNLOAD_BUTTON_URL . 'assets/css/download-button.css',
            [],
            ELEMENTOR_DOWNLOAD_BUTTON_VERSION
        );
    }
    
    public function admin_notice_missing_elementor() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requiere que "%2$s" esté instalado y activado.', 'elementor-download-button'),
            '<strong>' . esc_html__('Elementor Download Button', 'elementor-download-button') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'elementor-download-button') . '</strong>'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
    
    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);
        
        $message = sprintf(
            esc_html__('"%1$s" requiere la versión "%2$s" de "%3$s" o superior.', 'elementor-download-button'),
            '<strong>' . esc_html__('Elementor Download Button', 'elementor-download-button') . '</strong>',
            '3.0.0',
            '<strong>' . esc_html__('Elementor', 'elementor-download-button') . '</strong>'
        );
        
        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }
    
    public function register_widgets($widgets_manager) {
        require_once(ELEMENTOR_DOWNLOAD_BUTTON_PATH . 'widgets/download-button-widget.php');
        $widgets_manager->register(new \Elementor_Download_Button_Widget());
    }
    
    public function add_elementor_widget_categories($elements_manager) {
        $elements_manager->add_category(
            'download-elements',
            [
                'title' => esc_html__('Descarga', 'elementor-download-button'),
                'icon' => 'fa fa-plug',
            ]
        );
    }
}

Elementor_Download_Button::instance();
