<?php
/**
 * Download Button Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class Elementor_Download_Button_Widget extends \Elementor\Widget_Base {
    
    public function get_name() {
        return 'download_button';
    }
    
    public function get_title() {
        return __('Botón de Descarga', 'elementor-download-button');
    }
    
    public function get_icon() {
        return 'eicon-download-button';
    }
    
    public function get_categories() {
        return ['download-elements'];
    }
    
    public function get_keywords() {
        return ['download', 'button', 'file', 'descarga', 'archivo', 'botón'];
    }
    
    protected function register_controls() {
        
        // ===== SECCIÓN DE CONTENIDO =====
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Contenido', 'elementor-download-button'),
            ]
        );
        
        $this->add_control(
            'file',
            [
                'label' => __('Seleccionar Archivo', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'media_types' => ['application', 'video', 'audio', 'image'],
                'default' => [
                    'url' => '',
                ],
                'description' => __('Elige el archivo que los usuarios descargarán', 'elementor-download-button'),
            ]
        );
        
        $this->add_control(
            'button_text',
            [
                'label' => __('Texto del Botón', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Descargar Archivo', 'elementor-download-button'),
                'placeholder' => __('Escribe el texto aquí', 'elementor-download-button'),
            ]
        );
        
        $this->add_control(
            'selected_icon',
            [
                'label' => __('Icono', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-download',
                    'library' => 'fa-solid',
                ],
                'recommended' => [
                    'fa-solid' => [
                        'download',
                        'file-download',
                        'arrow-down',
                        'cloud-download-alt',
                    ],
                ],
            ]
        );
        
        $this->add_control(
            'icon_align',
            [
                'label' => __('Posición del Icono', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => __('Izquierda', 'elementor-download-button'),
                    'right' => __('Derecha', 'elementor-download-button'),
                ],
            ]
        );
        
        $this->add_control(
            'force_download',
            [
                'label' => __('Forzar Descarga', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Sí', 'elementor-download-button'),
                'label_off' => __('No', 'elementor-download-button'),
                'return_value' => 'yes',
                'default' => 'yes',
                'description' => __('Si está activado, el archivo se descargará automáticamente. Si no, se abrirá en una nueva pestaña.', 'elementor-download-button'),
            ]
        );
        
        $this->add_responsive_control(
            'align',
            [
                'label' => __('Alineación', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Izquierda', 'elementor-download-button'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Centro', 'elementor-download-button'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Derecha', 'elementor-download-button'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __('Justificado', 'elementor-download-button'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'prefix_class' => 'elementor%s-align-',
                'default' => '',
            ]
        );
        
        $this->end_controls_section();
        
        // ===== SECCIÓN DE ESTILO - BOTÓN =====
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Estilo del Botón', 'elementor-download-button'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} .elementor-button',
            ]
        );
        
        $this->start_controls_tabs('tabs_button_style');
        
        // Tab Normal
        $this->start_controls_tab(
            'tab_button_normal',
            [
                'label' => __('Normal', 'elementor-download-button'),
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Color del Texto', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .elementor-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .elementor-button svg' => 'fill: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'background_color',
            [
                'label' => __('Color de Fondo', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0073aa',
                'selectors' => [
                    '{{WRAPPER}} .elementor-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        // Tab Hover
        $this->start_controls_tab(
            'tab_button_hover',
            [
                'label' => __('Hover', 'elementor-download-button'),
            ]
        );
        
        $this->add_control(
            'hover_color',
            [
                'label' => __('Color del Texto', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .elementor-button:hover svg' => 'fill: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_background_hover_color',
            [
                'label' => __('Color de Fondo', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_hover_border_color',
            [
                'label' => __('Color del Borde', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();
        
        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .elementor-button',
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'border_radius',
            [
                'label' => __('Radio del Borde', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .elementor-button',
            ]
        );
        
        $this->add_responsive_control(
            'text_padding',
            [
                'label' => __('Padding', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
        
        $this->end_controls_section();
        
        // ===== SECCIÓN DE ESTILO - ICONO =====
        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => __('Icono', 'elementor-download-button'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'icon_size',
            [
                'label' => __('Tamaño del Icono', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 6,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button .elementor-button-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'icon_spacing',
            [
                'label' => __('Espaciado del Icono', 'elementor-download-button'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button .elementor-align-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .elementor-button .elementor-align-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Verificar que hay un archivo seleccionado
        if (empty($settings['file']['url'])) {
            ?>
            <div class="elementor-alert elementor-alert-warning" style="padding: 15px; background: #fff3cd; border-left: 4px solid #ffc107; margin: 10px 0; color: #856404;">
                <strong>Aviso:</strong> Por favor, selecciona un archivo en la configuración del widget.
            </div>
            <?php
            return;
        }
        
        $this->add_render_attribute('wrapper', 'class', 'elementor-button-wrapper');
        
        $this->add_render_attribute('button', 'href', esc_url($settings['file']['url']));
        $this->add_render_attribute('button', 'class', 'elementor-button');
        $this->add_render_attribute('button', 'role', 'button');
        
        if ($settings['force_download'] === 'yes') {
            $filename = basename($settings['file']['url']);
            $this->add_render_attribute('button', 'download', $filename);
        } else {
            $this->add_render_attribute('button', 'target', '_blank');
            $this->add_render_attribute('button', 'rel', 'noopener noreferrer');
        }
        
        if (!empty($settings['button_text'])) {
            $this->add_render_attribute('button', 'class', 'elementor-button-link');
        }
        
        $this->add_render_attribute('button-text', 'class', 'elementor-button-text');
        
        $migrated = isset($settings['__fa4_migrated']['selected_icon']);
        $is_new = empty($settings['icon']) && \Elementor\Icons_Manager::is_migration_allowed();
        
        ?>
        <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
            <a <?php echo $this->get_render_attribute_string('button'); ?>>
                <?php if (!empty($settings['selected_icon']['value'])) : ?>
                    <span class="elementor-button-content-wrapper">
                        <?php if ($settings['icon_align'] === 'left') : ?>
                            <span class="elementor-button-icon elementor-align-icon-<?php echo esc_attr($settings['icon_align']); ?>">
                                <?php
                                if ($is_new || $migrated) {
                                    \Elementor\Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']);
                                } else {
                                    ?>
                                    <i class="<?php echo esc_attr($settings['icon']); ?>" aria-hidden="true"></i>
                                    <?php
                                }
                                ?>
                            </span>
                        <?php endif; ?>
                        <span <?php echo $this->get_render_attribute_string('button-text'); ?>><?php echo esc_html($settings['button_text']); ?></span>
                        <?php if ($settings['icon_align'] === 'right') : ?>
                            <span class="elementor-button-icon elementor-align-icon-<?php echo esc_attr($settings['icon_align']); ?>">
                                <?php
                                if ($is_new || $migrated) {
                                    \Elementor\Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']);
                                } else {
                                    ?>
                                    <i class="<?php echo esc_attr($settings['icon']); ?>" aria-hidden="true"></i>
                                    <?php
                                }
                                ?>
                            </span>
                        <?php endif; ?>
                    </span>
                <?php else : ?>
                    <span <?php echo $this->get_render_attribute_string('button-text'); ?>><?php echo esc_html($settings['button_text']); ?></span>
                <?php endif; ?>
            </a>
        </div>
        <?php
    }
    
    protected function content_template() {
        ?>
        <#
        view.addRenderAttribute('button', {
            'class': ['elementor-button', 'elementor-button-link'],
            'href': settings.file.url,
            'role': 'button'
        });
        
        if (settings.force_download === 'yes') {
            var filename = settings.file.url.split('/').pop();
            view.addRenderAttribute('button', 'download', filename);
        } else {
            view.addRenderAttribute('button', {
                'target': '_blank',
                'rel': 'noopener noreferrer'
            });
        }
        
        view.addRenderAttribute('button-text', 'class', 'elementor-button-text');
        
        var iconHTML = elementor.helpers.renderIcon(view, settings.selected_icon, { 'aria-hidden': true }, 'i' , 'object');
        #>
        <# if (!settings.file.url) { #>
            <div class="elementor-alert elementor-alert-warning" style="padding: 15px; background: #fff3cd; border-left: 4px solid #ffc107; margin: 10px 0; color: #856404;">
                <strong>Aviso:</strong> Por favor, selecciona un archivo en la configuración del widget.
            </div>
        <# } else { #>
            <div class="elementor-button-wrapper">
                <a {{{ view.getRenderAttributeString('button') }}}>
                    <# if (settings.selected_icon.value) { #>
                        <span class="elementor-button-content-wrapper">
                            <# if (settings.icon_align === 'left') { #>
                                <span class="elementor-button-icon elementor-align-icon-{{ settings.icon_align }}">
                                    {{{ iconHTML.value }}}
                                </span>
                            <# } #>
                            <span {{{ view.getRenderAttributeString('button-text') }}}>{{{ settings.button_text }}}</span>
                            <# if (settings.icon_align === 'right') { #>
                                <span class="elementor-button-icon elementor-align-icon-{{ settings.icon_align }}">
                                    {{{ iconHTML.value }}}
                                </span>
                            <# } #>
                        </span>
                    <# } else { #>
                        <span {{{ view.getRenderAttributeString('button-text') }}}>{{{ settings.button_text }}}</span>
                    <# } #>
                </a>
            </div>
        <# } #>
        <?php
    }
}
