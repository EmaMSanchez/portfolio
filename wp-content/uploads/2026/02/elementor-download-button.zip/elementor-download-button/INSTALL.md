# Instalación Rápida

## Estructura de Archivos

Tu plugin debe tener la siguiente estructura:

```
elementor-download-button/
├── elementor-download-button.php    (archivo principal)
├── widgets/
│   └── download-button-widget.php
├── assets/
│   └── css/
│       └── download-button.css
└── README.md
```

## Pasos de Instalación

### 1. Preparar los Archivos

Coloca todos los archivos en una carpeta llamada `elementor-download-button` manteniendo la estructura mostrada arriba.

### 2. Subir a WordPress

**Opción A - FTP/Hosting:**
1. Sube la carpeta completa a: `wp-content/plugins/`
2. La ruta final debe ser: `wp-content/plugins/elementor-download-button/`

**Opción B - Panel de WordPress:**
1. Comprime la carpeta `elementor-download-button` en un archivo ZIP
2. Ve a: **Plugins > Añadir nuevo > Subir plugin**
3. Selecciona el ZIP y sube
4. Activa el plugin

### 3. Activar el Plugin

1. Ve a **Plugins** en tu panel de WordPress
2. Busca "Elementor Download Button"
3. Haz clic en **Activar**

### 4. Verificar la Instalación

1. Edita cualquier página con Elementor
2. En el panel izquierdo, busca la categoría "Descarga"
3. Debe aparecer el widget "Botón de Descarga"

## Primer Uso

1. Arrastra el widget "Botón de Descarga" a tu página
2. Haz clic en "Elegir archivo" en la sección "Contenido"
3. Selecciona un archivo de tu biblioteca de medios
4. Personaliza el texto y estilos según tus necesidades
5. ¡Listo! Publica la página

## Problemas Comunes

**El widget no aparece:**
- Verifica que Elementor esté instalado (versión 3.0.0 o superior)
- Refresca la página del editor de Elementor
- Limpia la caché si usas un plugin de caché

**Error al activar:**
- Verifica que todos los archivos estén en las carpetas correctas
- Verifica los permisos de archivos (644 para archivos, 755 para carpetas)

**Los estilos no se aplican:**
- Ve a: **Elementor > Herramientas > Regenerar CSS**
- Limpia la caché del navegador (Ctrl+Shift+R)
