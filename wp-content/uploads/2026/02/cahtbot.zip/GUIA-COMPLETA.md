# 📦 AI CHATBOT PARA ELEMENTOR - GUÍA COMPLETA

## 🎯 ¿Qué incluye este paquete?

```
ai-chatbot-elementor/
├── ai-chatbot-elementor.php    (Archivo principal del plugin)
├── README.md                    (Documentación completa)
├── INSTALACION.md              (Guía rápida)
├── CHANGELOG.md                (Historial de cambios)
├── LICENSE.txt                 (Licencia GPL v2)
├── includes/
│   ├── admin-settings.php      (Panel de administración)
│   └── elementor-widget.php    (Widget de Elementor)
├── templates/
│   └── chatbot.php             (Template del chatbot)
└── assets/
    ├── css/
    │   ├── chatbot.css         (Estilos del chatbot)
    │   └── admin.css           (Estilos del admin)
    └── js/
        └── chatbot.js          (Funcionalidad JavaScript)
```

## 🚀 INSTALACIÓN EN 3 PASOS

### PASO 1: Subir el Plugin a WordPress

**Método A: Subida ZIP (Recomendado)**
1. En WordPress Admin, ve a **Plugins → Añadir nuevo**
2. Haz clic en **Subir Plugin**
3. Selecciona el archivo `ai-chatbot-elementor.zip`
4. Haz clic en **Instalar ahora**
5. Haz clic en **Activar Plugin**

**Método B: FTP/Archivo Manager**
1. Descomprime `ai-chatbot-elementor.zip`
2. Sube la carpeta `ai-chatbot-elementor` a `/wp-content/plugins/`
3. Ve a WordPress Admin → Plugins
4. Activa "AI Chatbot for Elementor"

### PASO 2: Obtener API Key de Anthropic

1. Ve a: https://console.anthropic.com/
2. Crea una cuenta o inicia sesión
3. Ve a la sección **API Keys**
4. Haz clic en **Create Key**
5. Copia tu nueva API key (empieza con `sk-ant-...`)
6. ⚠️ Guárdala en un lugar seguro

### PASO 3: Configurar el Plugin

1. En WordPress Admin, verás un nuevo menú **AI Chatbot**
2. Haz clic en **AI Chatbot**
3. En la sección **Configuración de API**:
   - Pega tu API Key
   - Selecciona el modelo (recomendado: **Claude Sonnet 4**)
   - Personaliza el Prompt del Sistema
4. En la sección **Apariencia**:
   - Elige tu color principal
   - Selecciona la posición del chatbot
5. En la sección **Mensajes**:
   - Personaliza el mensaje de bienvenida
   - Ajusta el placeholder del input
6. Haz clic en **Guardar Cambios**

## 💡 CÓMO USAR EL CHATBOT

### Opción 1: Widget de Elementor (Visual)

```
1. Abre cualquier página con Elementor
2. En el panel izquierdo, busca "AI Chatbot"
3. Arrastra el widget a tu página
4. En el panel derecho, personaliza:
   
   PESTAÑA CONTENIDO:
   - Título del Chat: "Asistente Virtual"
   - Mensaje de Bienvenida: "¡Hola! ¿Cómo puedo ayudarte?"
   - Posición: Elige entre flotante o embebido
   
   PESTAÑA ESTILO:
   - Color Principal: Tu color de marca
   - Ancho y Alto: Ajusta el tamaño
   - Bordes y Sombras: Personaliza el diseño
   
5. Haz clic en PUBLICAR o ACTUALIZAR
6. ¡Prueba tu chatbot!
```

### Opción 2: Shortcode (En cualquier lugar)

Agrega este shortcode en páginas, posts o widgets:

```
[ai_chatbot]
```

**Con parámetros personalizados:**

```
[ai_chatbot 
    title="Soporte 24/7" 
    color="#2563eb" 
    position="bottom-right" 
    welcome="¡Bienvenido! ¿En qué puedo ayudarte hoy?"]
```

**Parámetros disponibles:**
- `title` - Título del chatbot
- `color` - Color principal (hexadecimal)
- `position` - `bottom-right`, `bottom-left`, o `inline`
- `welcome` - Mensaje de bienvenida

### Opción 3: En tu Theme (Para desarrolladores)

En `functions.php` o en tus templates:

```php
<?php
// Verificar que el plugin esté activo
if (function_exists('ai_chatbot_elementor_init')) {
    echo do_shortcode('[ai_chatbot]');
}
?>
```

## 🎨 EJEMPLOS DE USO REAL

### Para E-commerce
```
[ai_chatbot 
    title="Asistente de Compras" 
    color="#10b981"
    welcome="¡Hola! Estoy aquí para ayudarte a encontrar el producto perfecto. ¿Qué estás buscando?"]
```

**Prompt del Sistema:**
```
Eres un asistente de ventas experto en [tu tienda]. 
Ayudas a los clientes a encontrar productos, responder 
preguntas sobre envíos, devoluciones y características 
de productos. Sé amigable y persuasivo sin ser agresivo.
```

### Para Soporte Técnico
```
[ai_chatbot 
    title="Soporte 24/7" 
    color="#2563eb"
    welcome="Bienvenido al soporte técnico. Describe tu problema y te ayudaré a resolverlo."]
```

**Prompt del Sistema:**
```
Eres un especialista en soporte técnico. Tu objetivo es 
diagnosticar y resolver problemas de los usuarios de manera 
clara y paso a paso. Si no puedes resolver algo, 
proporciona instrucciones para contactar al equipo humano.
```

### Para Restaurante
```
[ai_chatbot 
    title="Reservas" 
    color="#f59e0b"
    position="bottom-left"
    welcome="¡Bienvenido! ¿Te gustaría hacer una reserva o ver nuestro menú?"]
```

**Prompt del Sistema:**
```
Eres el asistente de [nombre del restaurante]. 
Ayudas con reservas, información del menú, horarios 
y ubicación. Sé cálido y acogedor, como un anfitrión profesional.
```

## ⚙️ CONFIGURACIÓN AVANZADA

### Personalizar el Prompt del Sistema

El prompt del sistema define la personalidad y comportamiento del chatbot:

**Elementos clave para un buen prompt:**

1. **Identidad**: Define quién es el bot
   ```
   Eres un asistente virtual de [tu empresa/sitio].
   ```

2. **Propósito**: Qué debe hacer
   ```
   Tu objetivo es ayudar a los visitantes con [tareas específicas].
   ```

3. **Tono**: Cómo debe comunicarse
   ```
   Responde de manera amigable, profesional y concisa.
   ```

4. **Restricciones**: Qué NO debe hacer
   ```
   No proporciones información sobre precios sin verificar.
   Si no sabes algo, admítelo honestamente.
   ```

**Ejemplo completo:**
```
Eres un asistente virtual de la empresa TechSolutions. 
Tu objetivo es ayudar a los visitantes con información 
sobre nuestros productos de software, planes de precios 
y soporte técnico básico. 

Responde de manera profesional pero amigable, usando 
un lenguaje claro y evitando jerga técnica compleja. 

Si un problema requiere intervención humana, proporciona 
el contacto del equipo de soporte: soporte@techsolutions.com

Siempre termina tus respuestas preguntando si el usuario 
necesita ayuda adicional.
```

## 🎯 CASOS DE USO ESPECÍFICOS

### Captura de Leads
```
Prompt del Sistema:
"Eres un asistente de ventas. Cuando un usuario muestre 
interés en un producto o servicio, ofrécele amablemente 
enviarte más información por email. Pregunta por su correo 
de forma natural en la conversación."
```

### FAQ Automatizado
```
Prompt del Sistema:
"Eres un experto en las preguntas frecuentes de [tu empresa]. 
Tienes conocimiento profundo sobre: [lista los temas principales].
Proporciona respuestas precisas y detalladas. Si te preguntan 
algo fuera de estos temas, sugiere contactar al equipo humano."
```

### Reservas y Citas
```
Prompt del Sistema:
"Ayudas a los clientes a agendar citas. Pregunta por:
1. Tipo de servicio deseado
2. Fecha y hora preferida
3. Nombre y contacto
Luego, proporciona un mensaje de confirmación con los pasos siguientes."
```

## 📊 MONITOREAR USO Y COSTOS

### Revisar tu consumo de API:

1. Ve a: https://console.anthropic.com/
2. Haz clic en **Usage**
3. Verás gráficos de:
   - Tokens consumidos por día
   - Costo aproximado
   - Número de peticiones

### Optimizar costos:

**1. Elige el modelo correcto:**
- **Haiku**: Más económico, respuestas rápidas
- **Sonnet**: Balance perfecto (recomendado)
- **Opus**: Más caro, para casos complejos

**2. Limita el historial:**
El plugin guarda el contexto completo. Para reducir costos, 
puedes modificar el código para limitar a los últimos 5-10 mensajes.

**3. Usa prompts concisos:**
Prompts más cortos = menos tokens = menor costo

### Costos aproximados:
```
Claude Haiku 4:
- ~$0.25 por millón de tokens entrada
- 1,000 conversaciones ≈ $0.50 - $1.00

Claude Sonnet 4 (Recomendado):
- ~$3.00 por millón de tokens entrada
- 1,000 conversaciones ≈ $6.00 - $12.00

Claude Opus 4:
- ~$15.00 por millón de tokens entrada
- 1,000 conversaciones ≈ $30.00 - $60.00
```

## 🔧 SOLUCIÓN DE PROBLEMAS

### Problema 1: "API key no configurada"
**Solución:**
1. Ve a WordPress Admin → AI Chatbot
2. Verifica que hayas pegado la API key correctamente
3. Asegúrate de no tener espacios al inicio o final
4. Haz clic en Guardar Cambios

### Problema 2: El chatbot no responde
**Causas posibles:**
- API key inválida o expirada
- Límite de uso de la API alcanzado
- Problema de conectividad

**Solución:**
1. Verifica tu API key en https://console.anthropic.com/
2. Revisa el uso y límites de tu cuenta
3. Abre la consola del navegador (F12) y busca errores
4. Verifica que tu servidor permita conexiones HTTPS externas

### Problema 3: El widget no aparece en Elementor
**Solución:**
1. Verifica que Elementor esté instalado y activado
2. Ve a Elementor → Herramientas
3. Haz clic en "Regenerar Archivos CSS"
4. Limpia la caché de Elementor
5. Refresca la página de edición

### Problema 4: Estilos no se aplican
**Solución:**
1. Limpia la caché del navegador (Ctrl + Shift + Del)
2. Limpia la caché de WordPress (si usas plugin)
3. Verifica que los archivos CSS se estén cargando:
   - Abre la consola del navegador (F12)
   - Ve a la pestaña Network
   - Busca `chatbot.css`
4. Verifica permisos de la carpeta `/assets/`

### Problema 5: Error 403 o 401 de la API
**Solución:**
- Error 401: API key inválida → Genera una nueva
- Error 403: Límite de uso alcanzado → Revisa tu plan en Anthropic

## 🔐 SEGURIDAD Y MEJORES PRÁCTICAS

### ✅ HACER:
- Mantener la API key privada y segura
- Monitorear el uso regularmente
- Actualizar el plugin cuando haya nuevas versiones
- Hacer backups antes de actualizaciones
- Probar en staging antes de producción

### ❌ NO HACER:
- Compartir tu API key públicamente
- Commitear la API key a repositorios públicos
- Dar acceso al panel admin a usuarios no confiables
- Ignorar los límites de uso de la API

## 📈 PRÓXIMOS PASOS

### Después de la instalación:

1. **Prueba exhaustiva**: Usa el chatbot desde diferentes dispositivos
2. **Ajusta el prompt**: Refina la personalidad según respuestas
3. **Monitorea conversaciones**: Observa patrones y mejora el bot
4. **Feedback de usuarios**: Pregunta qué tal funciona
5. **Optimiza costos**: Ajusta modelo según necesidades reales

## 💬 EJEMPLOS DE PROMPTS EFECTIVOS

### Para un Blog Personal
```
Eres un asistente virtual amigable e informal del blog de [nombre].
Conoces todos los artículos sobre [temas principales].
Ayudas a los lectores a encontrar contenido relevante y 
respondes preguntas sobre los posts. Usa un tono casual 
y entusiasta, como si estuvieras charlando con un amigo.
```

### Para Servicios Profesionales
```
Eres el asistente virtual de [nombre del despacho].
Proporcionas información sobre nuestros servicios de [tipo de servicios].
Respondes de manera profesional y confidencial.
Para consultas específicas o cotizaciones, solicita datos de 
contacto para que un especialista se comunique.
```

### Para Educación Online
```
Eres un tutor virtual que ayuda a estudiantes con información 
sobre los cursos de [plataforma]. Conoces los temarios, 
requisitos previos y duración de cada curso. 
Motivas a los estudiantes y respondes dudas académicas básicas.
Para asesoría personalizada, diriges a los estudiantes con el equipo.
```

## 📞 SOPORTE Y RECURSOS

### Documentación Oficial:
- **Claude API Docs**: https://docs.anthropic.com/
- **Elementor Docs**: https://elementor.com/help/
- **WordPress Codex**: https://codex.wordpress.org/

### Recursos Útiles:
- **Anthropic Console**: https://console.anthropic.com/
- **Prompt Engineering**: https://docs.anthropic.com/claude/docs/prompt-engineering
- **Best Practices**: https://docs.anthropic.com/claude/docs/claude-on-amazon-bedrock

### Comunidad:
- **Stack Overflow**: Tag `anthropic-claude`
- **WordPress Forums**: Plugin Support Section
- **GitHub**: Reporta issues y sugiere mejoras

## ✨ ¡DISFRUTA TU CHATBOT!

Ya estás listo para ofrecer una experiencia de chat con IA 
a tus visitantes. Recuerda que la IA aprende y mejora con 
un buen prompt del sistema.

**Consejo final**: Empieza simple y ve refinando el comportamiento 
del bot basándote en las conversaciones reales de tus usuarios.

---

**¿Preguntas?** Consulta el README.md completo incluido en el paquete.

**¡Éxito con tu chatbot!** 🚀🤖
