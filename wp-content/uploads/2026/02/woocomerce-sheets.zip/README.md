# WooCommerce Payments Exporter

Plugin de WordPress para exportar pagos de WooCommerce a Excel y Google Sheets con panel de administración completo.

## 📋 Características

- ✅ Exportación a Excel (.xlsx) y CSV
- ✅ Integración con Google Sheets
- ✅ Panel de administración en WordPress
- ✅ Exportación automática de nuevos pedidos
- ✅ Exportación por rango de fechas
- ✅ Exportación individual desde el pedido
- ✅ Sincronización completa con Google Sheets
- ✅ Configuración de credenciales desde el panel

## 📦 Instalación

### Opción 1: Instalación Manual

1. Descarga todos los archivos del plugin
2. Crea la siguiente estructura de carpetas:
```
woocommerce-payments-exporter/
├── woocommerce-payments-exporter.php
├── includes/
│   ├── admin-menu.php
│   ├── export-functions.php
│   └── google-sheets.php
└── README.md
```

3. Comprime la carpeta `woocommerce-payments-exporter` en un archivo .zip
4. Ve a WordPress → Plugins → Añadir nuevo → Subir plugin
5. Sube el archivo .zip y activa el plugin

### Opción 2: Instalación por FTP

1. Sube la carpeta `woocommerce-payments-exporter` a `/wp-content/plugins/`
2. Ve a WordPress → Plugins y activa "WooCommerce Payments Exporter"

## ⚙️ Configuración

### Configuración Básica

1. Ve a **Payments Exporter** en el menú de WordPress
2. En la pestaña **Configuración**:
   - Elige el formato de exportación (Excel o CSV)
   - Configura otras opciones según tus necesidades

### Configuración de Google Sheets

#### Paso 1: Crear Proyecto en Google Cloud

1. Ve a [Google Cloud Console](https://console.cloud.google.com)
2. Crea un nuevo proyecto o selecciona uno existente
3. Habilita la **Google Sheets API**:
   - Ve a "APIs y servicios" → "Biblioteca"
   - Busca "Google Sheets API"
   - Haz clic en "Habilitar"

#### Paso 2: Crear Cuenta de Servicio

1. Ve a "APIs y servicios" → "Credenciales"
2. Haz clic en "Crear credenciales" → "Cuenta de servicio"
3. Dale un nombre y descripción
4. No necesitas asignar roles adicionales
5. Haz clic en "Listo"

#### Paso 3: Generar Clave JSON

1. Encuentra tu cuenta de servicio en la lista
2. Haz clic en ella
3. Ve a la pestaña "Claves"
4. Haz clic en "Agregar clave" → "Crear nueva clave"
5. Selecciona "JSON" y descarga el archivo

#### Paso 4: Configurar en WordPress

1. Abre el archivo JSON descargado
2. Copia **TODO** el contenido
3. Ve a WordPress → Payments Exporter → Configuración
4. Pega el JSON en el campo "Credenciales de Google (JSON)"

#### Paso 5: Crear y Compartir Hoja de Cálculo

1. Ve a [Google Sheets](https://sheets.google.com)
2. Crea una nueva hoja de cálculo
3. Abre el archivo JSON de credenciales
4. Busca el campo `client_email` (algo como: `nombre@proyecto.iam.gserviceaccount.com`)
5. Comparte la hoja de Google Sheets con ese email (dale permisos de Editor)
6. Copia el ID de la hoja de cálculo desde la URL:
   ```
   https://docs.google.com/spreadsheets/d/[ESTE_ES_EL_ID]/edit
   ```
7. Pega el ID en WordPress → Payments Exporter → Configuración

#### Paso 6: Activar Integración

1. En la configuración del plugin, marca:
   - ✅ "Habilitar Google Sheets"
   - ✅ "Exportación Automática" (opcional)
2. Guarda los cambios

## 🚀 Uso

### Exportar Todos los Pedidos

1. Ve a **Payments Exporter**
2. Haz clic en **"Exportar Todos"**
3. Se descargará un archivo Excel con todos los pedidos

### Exportar por Rango de Fechas

1. Ve a **Payments Exporter**
2. Selecciona las fechas "Desde" y "Hasta"
3. Haz clic en **"Exportar Rango"**

### Exportar un Pedido Individual

1. Ve a **WooCommerce → Pedidos**
2. Abre cualquier pedido
3. En la barra lateral derecha, verás el box "Exportar Pago"
4. Haz clic en **"Exportar a Excel"** o **"Exportar a Google Sheets"**

### Sincronizar con Google Sheets

1. Ve a **Payments Exporter**
2. Haz clic en **"Sincronizar Ahora"**
3. Todos los pedidos se sincronizarán con tu hoja de Google Sheets

## 📊 Datos Exportados

El plugin exporta los siguientes campos de cada pedido:

- Número de Pedido
- Fecha
- Cliente (Nombre completo)
- Email
- Teléfono
- Dirección de facturación completa
- Total del pedido
- Método de pago
- Estado del pedido
- Productos (con cantidades)
- Cantidad total de items
- Notas del cliente

## 🔧 Solución de Problemas

### "WooCommerce no está instalado"

- Asegúrate de tener WooCommerce instalado y activado antes de usar este plugin

### "Error al exportar a Google Sheets"

- Verifica que las credenciales JSON sean válidas
- Asegúrate de haber compartido la hoja con el email de la cuenta de servicio
- Verifica que el ID de la hoja sea correcto
- Comprueba que la API de Google Sheets esté habilitada

### El archivo Excel no se descarga

- Verifica que tu servidor tenga la extensión ZIP de PHP habilitada
- Comprueba los permisos de escritura en el directorio temporal

### Los datos no aparecen en Google Sheets

- Verifica que hayas dado permisos de "Editor" a la cuenta de servicio
- Comprueba que el ID de la hoja sea correcto
- Revisa los logs de errores de WordPress

## 🔐 Seguridad

- Las credenciales de Google se almacenan encriptadas en la base de datos de WordPress
- Solo usuarios con permisos de `manage_woocommerce` pueden acceder al plugin
- Se utilizan nonces de WordPress para proteger los formularios

## 📝 Requisitos

- WordPress 5.0 o superior
- WooCommerce 3.0 o superior
- PHP 7.2 o superior
- Extensiones PHP: `openssl`, `zip`, `json`

## 🆘 Soporte

Si encuentras algún problema:

1. Verifica que todos los requisitos estén cumplidos
2. Revisa los logs de errores de WordPress
3. Asegúrate de que WooCommerce esté funcionando correctamente
4. Verifica la configuración de Google Sheets paso a paso

## 📄 Licencia

GPL v2 or later

## 🔄 Actualizaciones Futuras

Características planificadas:

- [ ] Filtros por método de pago
- [ ] Filtros por estado de pedido
- [ ] Exportación de productos individuales
- [ ] Estadísticas y gráficos
- [ ] Programación de exportaciones automáticas
- [ ] Integración con otras plataformas (Dropbox, OneDrive)
- [ ] Plantillas personalizables de exportación
- [ ] Webhooks para notificaciones

## 👨‍💻 Créditos

Plugin desarrollado para facilitar la gestión y exportación de datos de WooCommerce.

---

**¿Te fue útil este plugin?** Considera dejar una reseña ⭐
