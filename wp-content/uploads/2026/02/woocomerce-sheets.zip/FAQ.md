# ❓ Preguntas Frecuentes (FAQ)

## 📥 Instalación y Configuración

### ¿Necesito conocimientos técnicos para usar este plugin?

No. El plugin está diseñado para ser fácil de usar. Para exportar a Excel solo necesitas hacer clic en un botón. Para Google Sheets necesitarás seguir algunos pasos, pero están explicados claramente.

### ¿Funciona con mi versión de WordPress?

Sí, siempre que tengas:
- WordPress 5.0 o superior
- WooCommerce 3.0 o superior
- PHP 7.2 o superior

### ¿Es gratis?

Sí, el plugin es totalmente gratuito. La integración con Google Sheets también es gratuita si usas una cuenta de Google normal.

---

## 📊 Google Sheets

### ¿Por qué necesito una cuenta de servicio de Google?

Las cuentas de servicio permiten que tu sitio WordPress se comunique con Google Sheets de forma segura, sin necesidad de que inicies sesión cada vez.

### ¿Cómo obtengo el client_email del JSON?

Abre el archivo JSON que descargaste de Google Cloud y busca la línea:
```json
"client_email": "tu-cuenta@proyecto-123.iam.gserviceaccount.com"
```

Ese es el email que debes usar para compartir tu hoja de Google Sheets.

### ¿Qué permisos debo dar al compartir la hoja?

Debes dar permisos de **Editor**, no solo de Lector. El plugin necesita poder escribir en la hoja.

### ¿Puedo usar múltiples hojas de cálculo?

Por ahora, el plugin solo soporta una hoja a la vez. Si necesitas exportar a diferentes hojas, deberías cambiar el ID en la configuración cada vez.

### ¿Se sobreescriben los datos en Google Sheets?

Cuando usas "Sincronizar Ahora", la hoja se limpia completamente y se vuelve a llenar con todos los pedidos. Cuando exportas pedidos individuales, se agregan al final sin borrar datos existentes.

---

## 📤 Exportación

### ¿Qué pedidos se exportan?

Por defecto, se exportan pedidos con estado:
- Completado (Completed)
- Procesando (Processing)
- En espera (On Hold)

### ¿Puedo exportar pedidos cancelados o reembolsados?

Actualmente no, pero esta funcionalidad está planificada para futuras versiones.

### ¿Qué formato es mejor: Excel o CSV?

**Excel (.xlsx):** 
- ✅ Mejor formato
- ✅ Soporta más caracteres
- ✅ Mantiene formato
- ❌ Archivos más grandes

**CSV (.csv):**
- ✅ Archivos más pequeños
- ✅ Compatible con más programas
- ❌ Problemas con acentos en Excel (usar "importar datos")

### ¿Por qué mi CSV se ve raro en Excel?

Los archivos CSV pueden tener problemas con los caracteres especiales (ñ, á, é, etc.). Para solucionarlo:

1. En Excel, no abras el CSV directamente
2. Ve a Datos → Obtener datos → De archivo → De texto/CSV
3. Selecciona el archivo CSV
4. Asegúrate de que la codificación sea "UTF-8"
5. Importa los datos

O mejor aún, usa el formato Excel (.xlsx).

---

## 🔄 Automatización

### ¿Qué hace la "Exportación Automática"?

Cuando está activada, cada vez que un pedido cambia a estado "Completado" o "Procesando", se exporta automáticamente a tu hoja de Google Sheets.

### ¿Afecta la velocidad de mi tienda?

No. La exportación se hace en segundo plano y no afecta la experiencia del cliente.

### ¿Puedo desactivar la exportación automática?

Sí, simplemente desmarca la casilla en la configuración y guarda los cambios.

---

## 🔒 Seguridad

### ¿Es seguro guardar las credenciales en WordPress?

Sí. Las credenciales se guardan en la base de datos de WordPress con las mismas medidas de seguridad que usa WooCommerce para guardar información sensible. Solo usuarios con permisos de administrador de WooCommerce pueden acceder a ellas.

### ¿Quién puede exportar datos?

Solo usuarios con el permiso `manage_woocommerce` (generalmente administradores y gerentes de tienda).

---

## 💾 Datos y Formato

### ¿Qué información se exporta exactamente?

```
- Número de Pedido: #12345
- Fecha: 2024-01-15 14:30:00
- Cliente: Juan Pérez
- Email: juan@email.com
- Teléfono: +34 123 456 789
- Dirección: Calle Principal 123, Madrid, 28001, España
- Total: 99.99 EUR
- Método de Pago: Tarjeta de crédito
- Estado: Completado
- Productos: Producto A (x2), Producto B (x1)
- Cantidad Total: 3
- Notas: Por favor, enviar antes del viernes
```

### ¿Puedo personalizar los campos exportados?

En la versión actual no, pero es una característica planificada para futuras actualizaciones.

### ¿Se exportan los datos de productos individuales?

Sí, en la columna "Productos" se listan todos los productos del pedido con sus cantidades.

---

## 🛠️ Problemas Técnicos

### Error: "No se pudo obtener el token de acceso"

**Posibles causas:**
1. El JSON está incompleto o mal formateado
2. La extensión OpenSSL de PHP no está habilitada
3. El proyecto de Google Cloud no tiene permisos correctos

**Solución:**
1. Verifica que copiaste TODO el archivo JSON
2. Contacta con tu proveedor de hosting para verificar OpenSSL
3. Verifica que la API de Google Sheets esté habilitada

### Error: "Permission denied"

La cuenta de servicio no tiene permisos en la hoja.

**Solución:**
1. Abre tu hoja de Google Sheets
2. Clic en "Compartir"
3. Agrega el email de la cuenta de servicio (client_email del JSON)
4. Dar permisos de "Editor"

### No se descargan los archivos Excel

**Posible causa:** Extensión ZIP de PHP no habilitada

**Solución:**
Contacta con tu proveedor de hosting y pide que habiliten la extensión `zip` de PHP.

---

## 📈 Uso Avanzado

### ¿Puedo integrar esto con otras herramientas?

Sí. Una vez que los datos están en Google Sheets, puedes:
- Conectar con Google Data Studio para dashboards
- Usar fórmulas de Sheets para análisis
- Importar a Excel para trabajar offline
- Conectar con Zapier para automatizaciones

### Ejemplo: Dashboard automático con Google Sheets

1. Activa la exportación automática
2. Crea una segunda pestaña en tu hoja
3. Usa fórmulas para crear resúmenes:
```
=SUMA(G2:G1000)  // Total de ventas
=CONTAR(A2:A1000)  // Número de pedidos
=PROMEDIO(G2:G1000)  // Ticket promedio
```

### Ejemplo: Reportes mensuales automáticos

1. Usa la exportación por rango de fechas
2. Exporta cada mes (por ejemplo: 01/01/2024 - 31/01/2024)
3. Guarda cada Excel con un nombre descriptivo
4. Compara mes a mes

---

## 🔮 Roadmap (Futuras Funcionalidades)

### En desarrollo:
- [ ] Filtros por método de pago
- [ ] Filtros por estado de pedido
- [ ] Campos personalizables
- [ ] Múltiples hojas de Google Sheets
- [ ] Programación de exportaciones

### Sugerencias de usuarios:
¿Tienes una idea? Deja tu sugerencia en los comentarios o crea un issue.

---

## 📞 Contacto y Soporte

### Antes de pedir ayuda, verifica:

1. ✅ Requisitos del sistema cumplidos
2. ✅ WooCommerce funcionando correctamente
3. ✅ Has seguido la guía paso a paso
4. ✅ Has revisado esta FAQ

### ¿Dónde buscar ayuda?

1. **Logs de WordPress:** 
   `/wp-content/debug.log` (si tienes WP_DEBUG activado)

2. **Consola de Google Cloud:**
   Verifica que la API esté habilitada y las credenciales sean correctas

3. **Foro de WordPress:**
   Busca errores similares en forums.wordpress.org

---

## 💡 Consejos de Uso

### Para Contadores:
```
✓ Exportar al final del mes
✓ Usar rango de fechas
✓ Formato Excel para análisis
✓ Mantener backups mensuales
```

### Para Gerentes de Tienda:
```
✓ Activar exportación automática
✓ Sincronizar con Google Sheets
✓ Compartir hoja con equipo
✓ Crear dashboards en tiempo real
```

### Para Analistas:
```
✓ Exportar a Google Sheets
✓ Conectar con Data Studio
✓ Crear gráficos automáticos
✓ Analizar tendencias
```

---

**Última actualización:** Versión 1.0.0

**¿Te fue útil esta guía?** Considera dejar una valoración ⭐
