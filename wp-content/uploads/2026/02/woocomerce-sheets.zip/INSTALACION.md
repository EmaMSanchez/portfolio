# 🚀 Guía de Instalación Rápida

## ⏱️ 5 Minutos para Empezar

### 1️⃣ Instalar el Plugin (1 minuto)

```bash
# Opción A: Subir por WordPress
1. Comprimir carpeta woocommerce-payments-exporter en .zip
2. WordPress → Plugins → Añadir nuevo → Subir plugin
3. Activar

# Opción B: Por FTP
1. Subir carpeta a /wp-content/plugins/
2. Activar desde WordPress
```

### 2️⃣ Verificar Requisitos (30 segundos)

- ✅ WordPress 5.0+
- ✅ WooCommerce 3.0+
- ✅ PHP 7.2+

### 3️⃣ Primera Exportación (1 minuto)

1. Ve a **Payments Exporter** en el menú
2. Clic en **"Exportar Todos"**
3. ¡Listo! Ya tienes tu Excel con todos los pedidos

---

## 🔧 Configuración de Google Sheets (Opcional)

### Si quieres sincronizar con Google Sheets:

#### Paso 1: Google Cloud Console (2 minutos)

```
1. https://console.cloud.google.com
2. Crear proyecto
3. Habilitar "Google Sheets API"
4. Crear cuenta de servicio
5. Descargar JSON
```

#### Paso 2: Configurar en WordPress (1 minuto)

```
1. Copiar contenido del JSON
2. WordPress → Payments Exporter → Configuración
3. Pegar JSON en "Credenciales de Google"
```

#### Paso 3: Compartir Hoja (1 minuto)

```
1. Crear hoja en Google Sheets
2. Compartir con: cliente_email del JSON
3. Dar permisos de Editor
4. Copiar ID de la hoja (está en la URL)
5. Pegar ID en configuración del plugin
```

#### Paso 4: Activar (10 segundos)

```
✅ Marcar "Habilitar Google Sheets"
✅ Marcar "Exportación Automática" (opcional)
💾 Guardar cambios
```

---

## 📊 Ejemplo de Estructura del JSON

```json
{
  "type": "service_account",
  "project_id": "tu-proyecto",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...",
  "client_email": "cuenta@proyecto.iam.gserviceaccount.com",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  ...
}
```

**⚠️ Importante:** 
- Copia TODO el archivo JSON (desde { hasta })
- Busca el `client_email` para compartir la hoja

---

## 🎯 Casos de Uso Comunes

### 📈 Contador/Contabilidad
```
✓ Exportar todos los pedidos del mes
✓ Formato Excel para análisis
✓ Exportación por rango de fechas
```

### 📊 Análisis de Ventas
```
✓ Sincronizar con Google Sheets
✓ Crear dashboards automáticos
✓ Compartir con equipo
```

### 🔄 Automatización
```
✓ Activar exportación automática
✓ Cada nuevo pedido → Google Sheets
✓ Sin intervención manual
```

---

## 🆘 Solución Rápida de Errores

### ❌ "No puedo descargar el Excel"
```
→ Verificar extensión ZIP de PHP habilitada
→ Comprobar permisos de escritura
```

### ❌ "Error con Google Sheets"
```
→ Verificar JSON completo y válido
→ Compartir hoja con client_email del JSON
→ Dar permisos de Editor (no solo Lector)
→ API de Google Sheets debe estar habilitada
```

### ❌ "No aparecen los datos"
```
→ Verificar ID de la hoja correcto
→ Verificar que hoja esté compartida
→ Verificar estado de pedidos (completados, procesando)
```

---

## 💡 Tips Pro

1. **Backup antes de sincronizar:**
   Haz una copia de tu hoja antes de sincronizar todos los pedidos

2. **Filtrar por fechas:**
   Usa la exportación por rango para reportes mensuales

3. **Exportación individual:**
   Desde cada pedido puedes exportar solo ese registro

4. **Automatización:**
   Activa la exportación automática para tener datos siempre actualizados

---

## 📞 Contacto y Soporte

¿Dudas? Revisa:
- README.md completo
- Logs de WordPress
- Consola de Google Cloud

---

**¡Felicitaciones!** Ya puedes exportar tus pagos de WooCommerce 🎉
